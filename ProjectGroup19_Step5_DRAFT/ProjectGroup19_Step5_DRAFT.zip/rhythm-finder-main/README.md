# rhythm-finder
CS 340 Project

1. Download contents
2. Create `.env` file with the following information filled out:

````
PORT=
DB_HOST=
DB_USER=
DB_PASSWORD=
DB_NAME=
````

3. `npm i` to install appropriate node_modules
4. on local machine, `npm start`